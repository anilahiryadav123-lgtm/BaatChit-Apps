======================================================
  BaatChit Android App + Notification (GitHub, FREE)
======================================================

Is zip me 3 cheezein hain:
  1) baatchit-src.zip   -> poora Android app + push server (ise UNZIP mat karna, aise hi upload karna)
  2) build.yml          -> GitHub ka "robot" jo APK banata hai
  3) Ye README

Kya milega:
  - App band ho / phone lock ho tab bhi phone ke upar notification
    (Facebook / WhatsApp jaisa) : naya message, group message, reaction
  - Audio / Video call aane par ringtone + poori screen par call,
    "Answer" / "Decline" button ke saath
  - Sab kuch FREE (Firebase free plan + Cloudflare free plan + GitHub free)

------------------------------------------------------
STEP 1 : Firebase se 2 files (5 minute)
------------------------------------------------------
Firebase console kholein: https://console.firebase.google.com
Apna project "baatchit-87420" kholein.

(A) google-services.json
  - Upar ⚙ (Project settings) > General > neeche "Add app" > Android icon
  - Android package name likhein:   com.baatchit.app
  - App nickname: BaatChit  > "Register app"
  - "Download google-services.json" dabaiye  (phone me save ho jayegi)

(B) Service account key
  - ⚙ Project settings > "Service accounts" tab
  - "Generate new private key" > "Generate key"
  - Ek .json file download hogi. Ise kisi ko na dein!

(C) Realtime Database > Rules me "fcm" path ko read/write allow hona chahiye.
    Agar rules me ".read": true, ".write": true hai to kuch nahi karna.

------------------------------------------------------
STEP 2 : Cloudflare (push server ke liye, FREE)
------------------------------------------------------
  - https://dash.cloudflare.com/sign-up  par free account banayein
  - Left menu "Workers & Pages" kholein. Pehli baar ek naam (subdomain)
    choose karne ko bolega, koi bhi naam rakh dein.
  - Isi page par right side "Account ID" dikhega > copy karke rakh lein
  - Upar profile icon > "My Profile" > "API Tokens" > "Create Token"
    > template "Edit Cloudflare Workers" > "Use template"
    > neeche "Continue to summary" > "Create Token" > token copy kar lein

------------------------------------------------------
STEP 3 : GitHub par repo
------------------------------------------------------
  - github.com > "+" > New repository > naam: BaatChit
    > "Private" chunein (behtar) > Create repository
  - "uploading an existing file" / Add file > Upload files:
        baatchit-src.zip
        google-services.json
    > "Commit changes"

------------------------------------------------------
STEP 4 : GitHub Secrets (sirf ek baar)
------------------------------------------------------
Repo > Settings > Secrets and variables > Actions > "New repository secret"
3 secrets banayein (naam bilkul aise hi likhein):

  FIREBASE_SERVICE_ACCOUNT  = Step 1(B) wali .json file ka POORA text
                              (file ko text editor me khol kar sab copy-paste)
  CLOUDFLARE_API_TOKEN      = Step 2 ka token
  CLOUDFLARE_ACCOUNT_ID     = Step 2 ka Account ID

------------------------------------------------------
STEP 5 : build.yml lagayein  (isse APK banna shuru hoga)
------------------------------------------------------
  - Repo > Add file > "Create new file"
  - File ka naam likhein:   .github/workflows/build.yml
    (slash "/" likhte hi folder ban jayega)
  - build.yml file ka poora text copy karke yahan paste karein
  - "Commit changes"

  Ab "Actions" tab me build chalega (6-10 minute).
  Hara ✔ aane ke baad: repo ke home page par right side "Releases"
  > "BaatChit vX" > BaatChit-vX.apk download > install.

------------------------------------------------------
STEP 6 : Phone me install
------------------------------------------------------
  - Purana BaatChit (Html to APK wala) pehle Uninstall karein
    (dono ka package alag hai). Chats Firebase me safe hain,
    dobara login karte hi wapas aa jayengi.
  - Naya APK install karein, kholein, "Notifications Allow" karein.
  - Vivo / Oppo / Realme / Xiaomi phone me ZAROOR karein:
      Settings > Apps > BaatChit > Battery > "No restrictions"/"Allow background"
      aur "Auto start" ON
    warna phone app ko band kar deta hai aur notification late aati hai.

TEST: Do phone lein. Phone 2 par BaatChit band kar dein (home button).
Phone 1 se message bhejein -> Phone 2 ki screen ke upar notification aayegi.
Call karein -> Phone 2 par ringtone + Answer/Decline.

------------------------------------------------------
Aage update kaise karein
------------------------------------------------------
  - Naya HTML mile to use "index.html" naam se repo me upload kar dein
    (Add file > Upload files). Apne aap naya APK ban jayega.
  - Har naye APK ka version number badhta hai, isliye purane ke upar
    seedha install (update) ho jayega, data nahi jayega.

Problem aaye to Actions tab me laal ✗ wale run par tap karke
error ka screenshot bhej dein.

------------------------------------------------------
DeepAR FACE FILTERS (camera me 6 filters)
------------------------------------------------------
License key code me NAHI likhi hai, GitHub Secret me rakhni hai:
  1) GitHub repo > Settings > Secrets and variables > Actions
  2) "New repository secret"
       Name  : DEEPAR_KEY
       Secret: apni DeepAR license key paste karein
  3) Actions > Build > "Run workflow"
DeepAR website par app ka "Android App ID" bilkul  com.baatchit.app  hona chahiye,
warna key kaam nahi karegi.
Filter files: android/app/src/main/assets/effects/*.deepar

VIDEO CALL me DeepAR filters (alag Web key chahiye)
  1) developer.deepar.ai > apna project > "Add app" > Web
     Domain:  appassets.androidplatform.net
  2) Jo Web license key mile, use GitHub secret me daalein:
       Name: DEEPAR_WEB_KEY
  3) build.yml naya wala lagayein, phir Run workflow

=== Pakka login (Security update, step 1) ===
- Firebase console > Authentication > "Get started" ek baar dabana zaroori hai (ho chuka hai).
- PIN ab Cloudflare push server par check hota hai aur Firebase login token milta hai.
- Har user ko naya APK daal kar ek baar PIN dalna hoga ("Security update" screen).
- Firebase > Authentication > Users me har login karne wale ka number dikhega.
- Sab family ke number wahan dikhne lagein, tab step 2 (pakke rules) lagaye jayenge.
- Optional: agar build summary me "Firebase API key nahi mili" aaye to
  GitHub secret FIREBASE_API_KEY me Firebase > Project settings > General > "Web API key" daalein.
